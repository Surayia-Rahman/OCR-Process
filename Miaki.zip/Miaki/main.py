import os
import cv2
import pytesseract
from pdf2image import convert_from_path
from PIL import Image
import numpy as np
import re
from tabulate import tabulate


# Function to convert a PDF file into images
# Each page of the PDF is saved as a PNG image

def convert_pdf_to_images(pdf_path, image_output_dir):
    poppler_path = r"C:\Program Files\Release-24.08.0-0\poppler-24.08.0\Library\bin"

    try:
        # Convert PDF pages into images
        images = convert_from_path(pdf_path, poppler_path=poppler_path)
    except Exception as e:
        print(f"Error converting PDF to images: {e}")
        return None

    # Create directory if it doesn't exist
    if not os.path.exists(image_output_dir):
        os.makedirs(image_output_dir)

    image_paths = []
    for i, image in enumerate(images):
        image_path = os.path.join(image_output_dir, f"page_{i + 1}.png")
        image.save(image_path, 'PNG')
        image_paths.append(image_path)
        print(f"Page {i + 1} saved as {image_path}")

    return image_paths


# Function to check if an image is blurry using the Laplacian variance method
def is_blurry(image, blur_threshold=100):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    variance = cv2.Laplacian(gray, cv2.CV_64F).var()  # Compute variance of Laplacian
    return variance < blur_threshold  # If variance is below threshold, image is blurry


# Function to preprocess an image before text extraction
def preprocess_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError("Image not found or unable to read the image.")

    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # Convert to grayscale

    blur_threshold = 60  # Define threshold for blur detection
    blur_status = is_blurry(image, blur_threshold)

    if blur_status:
        print("Image is blurry, enhancing sharpness...")
        sharpen_kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])  # Sharpening filter
        image = cv2.filter2D(image, -1, sharpen_kernel)

    print("Applying denoising...")
    denoised_image = cv2.fastNlMeansDenoising(gray_image, None, 10, 7, 21)  # Denoising filter

    print("Enhancing contrast...")
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))  # Contrast enhancement
    contrast_image = clahe.apply(denoised_image)

    print("Applying adaptive thresholding...")
    binary_image = cv2.adaptiveThreshold(
        contrast_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 15, 10
    )

    return binary_image


# Function to determine the type of document based on extracted text
def identify_document_type(text):
    if re.search(r'family certificate', text, re.IGNORECASE):
        return "FAMILY CERTIFICATE"
    elif re.search(r'nikahnama', text, re.IGNORECASE):
        return "NIKAHNAMA"
    elif re.search(r'marriage certificate', text, re.IGNORECASE):
        return "MARRIAGE CERTIFICATE"
    else:
        return "UNKNOWN DOCUMENT"


# Function to extract text from an image using OCR
def extract_text_from_image(image_path):
    preprocessed_image = preprocess_image(image_path)  # Preprocess image for better OCR accuracy
    processed_pil_image = Image.fromarray(preprocessed_image)  # Convert numpy array to PIL image
    extracted_text = pytesseract.image_to_string(processed_pil_image, lang="eng")  # Extract text using Tesseract
    return extracted_text


# Function to display extracted text in a table format
def display_text_in_table(text):
    lines = text.split('\n')  # Split text into lines
    table_data = [[line] for line in lines if line.strip()]  # Remove empty lines
    headers = ["Extracted Text"]
    print(tabulate(table_data, headers=headers, tablefmt="grid"))  # Print formatted table


# Main function to execute the document processing workflow
def main():
    pdf_path = r"C:\Users\boish\Downloads\All scan Docs\Doc 1 file 1.pdf"
    image_output_dir = r"C:\Users\boish\Downloads\All scan Docs\images_output"

    # Convert PDF to images
    image_paths = convert_pdf_to_images(pdf_path, image_output_dir)
    if not image_paths:
        print("No images generated from the PDF.")
        return

    first_image_path = image_paths[0]  # Process only the first page for now
    print(f"Processing the first image: {first_image_path}")

    extracted_text = extract_text_from_image(first_image_path)  # Extract text from image

    document_type = identify_document_type(extracted_text)  # Identify document type
    print("Identified Document Type:", document_type)

    print("\nExtracted Text Table:")
    display_text_in_table(extracted_text)  # Display extracted text in tabular format

    # Preprocess image for display
    preprocessed_image = preprocess_image(first_image_path)
    scale_percent = 44  # Resize image for better display
    width = int(preprocessed_image.shape[1] * scale_percent / 100)
    height = int(preprocessed_image.shape[0] * scale_percent / 100)
    resized_image = cv2.resize(preprocessed_image, (width, height))

    # Show preprocessed image
    cv2.imshow("Preprocessed Image (Resized)", resized_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


# Run the main function if this script is executed directly
if __name__ == "__main__":
    main()
